//wp json rst api tutrial http://v2.wp-api.org/reference/posts/
$j(document).ready(function(){
    
	$j.support.cors=true;
	 
	$j.ajax({
        url: website_url+'/wp-json/wp/v2/posts',
        data: {
            filter: {
            'posts_per_page': 10
            }
        },
        dataType: 'json',
        type: 'GET',
        success: function(data) {
			$j('.loader').fadeOut('slow');
           // alert("Data from Server"+JSON.stringify(data));
			for(var i=0;i<data.length;i++){
								 var post_id=data[i].id;
								 
								 var title=data[i].title.rendered;
								 //var image=data[i].featured_media;
								 var image="<img width='100' src='img/thumbnail.jpg' />";
								 var content=data[i].content.rendered;
								 
								 content=$j(content).text();
								 
								 var shortContent = jQuery.trim(content).substring(0, 400).split(" ").slice(0, -1).join(" ") + "...";
 								 
								 var output='<li class="ui-li-has-thumb"><a class="ui-btn ui-btn-icon-right ui-icon-carat-r" href="details.html?post_id='+post_id+'">'+
								 image+'<h2>'+title+'</h2><p>'+shortContent+'</p></a></li>';
								 
								 $j('.list').append(output);
							}
        },
        error: function(jqXHR,textStatus,errorThrown) {
           alert("Error fetching data from server "+errorThrown);
        }
    });
	
});	