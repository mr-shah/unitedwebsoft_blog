//wp json rst api tutrial http://v2.wp-api.org/reference/posts/
$j(document).ready(function(){
    var post_id=1127;
	
	$j.support.cors=true;
	 
	$j.ajax({
        url: website_url+'/wp-json/wp/v2/posts/'+post_id,
        data: {
            filter: {
             }
        },
        dataType: 'json',
        type: 'GET',
        success: function(data) {
			$j('.loader').fadeOut('slow');
           // alert("Data from Server"+JSON.stringify(data));
 								 
								 var title=data.title.rendered;
								 //var image=data[i].featured_media;
								 var image="<img width='100' src='img/thumbnail.jpg' />";
								 var content=data.content.rendered;
								 
 								  $j('.title').html(title);
 								 $j('.details').html(content);
  								 
         },
        error: function(jqXHR,textStatus,errorThrown) {
           alert("Error fetching data from server "+errorThrown);
        }
    });
	
});	