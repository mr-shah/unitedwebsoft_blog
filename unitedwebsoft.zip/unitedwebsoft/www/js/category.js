  //tutorial ref http://v2.wp-api.org/reference/categories/
  $j(document).ready(function(){
    
	$j.support.cors=true;
	 
	$j.ajax({
        url: website_url+'/wp-json/wp/v2/categories',
        data: {
            filter: {
             }
        },
        dataType: 'json',
        type: 'GET',
        success: function(data) {
           // alert("Data from Server"+JSON.stringify(data));
			for(var i=0;i<data.length;i++){
								 var cat_name=data[i].name;
								 
								 var output="<a href='' class='ui-link ui-btn ui-shadow ui-corner-all ' data-role='button'>"+cat_name+"</a>";
								 
								 $j('.category').append(output);
							}
        },
        error: function(jqXHR,textStatus,errorThrown) {
           // alert("Error loading category  from server "+errorThrown);
        }
    });
	
});	
